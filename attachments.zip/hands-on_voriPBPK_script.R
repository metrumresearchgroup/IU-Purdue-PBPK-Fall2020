## This R script compiles and runs simulations for voriPBPK model; tasks here follow `hands-on_voriPBPK`

## load libraries
rm(list=ls())
library(dplyr)
library(magrittr)
library(knitr)
library(ggplot2)
library(gridExtra)
library(mrgsolve)
library(FME)
library(nloptr)


## adjust general theme for plotting
th <- theme(plot.title=element_text(size=30),
            axis.title=element_text(size=25),
            axis.text=element_text(size=20),
            legend.text=element_text(size=20))

#############################################################################################
#######################################  Task 1  ##########################################
#############################################################################################

## Fill missing ODEs in `voriPBPK.cpp` model file and compile
modA <- mread("voriPBPK")

#############################################################################################
#############################################################################################


#############################################################################################
########################################  Task 2  ##########################################
#############################################################################################

# Simulate a 4 mg/kg IV infusion dose of voriconazole given to an adult male with a rate of 
# 4 mg/kg/h twice a day for 7 days. Compare the steady state plasma drug concentration-time 
# profiles from previous simulation to the observed data in `Adult_IV.csv`.
# (N.B.: observed data were digitized from Zane and Thakker (2014) paper using WebPlotDigitizer 
#   https://automeris.io/WebPlotDigitizer/): 

obs <- read.csv("Adult_IV.csv")

bw <- 73
amt = 4*bw
rate = 4*bw
cmt = "VEN"
ii = 12
addl = 13
ss = 1

sim <- as.data.frame(modA %>% 
                       ev(amt=amt, cmt=cmt, ii=ii, addl=addl, rate=rate, ss=ss) %>% 
                       mrgsim(delta = 0.1, end = 12)) %>% 
  dplyr::filter(row_number() != 1)  

gp <- ggplot() + 
  geom_point(data = obs, aes(x=time, y=obs, col="observed"), size=2.5) + 
  geom_errorbar(data = obs, aes(x = time, y = obs, ymin=obs-sd, ymax=obs+sd), width=0) +
  geom_line(data = sim, aes(x=time, y=Cvenous, col="sim"), lwd=1) + 
  scale_colour_manual(name='', 
                      values=c('sim'='black', 'observed'='black'), 
                      breaks=c("observed","sim"),
                      labels=c("observed","predicted")) +
  guides(colour = guide_legend(override.aes = list(linetype=c(0,1), shape=c(16, NA)))) +
  labs(title="Adult 4 mg/kg IV", x="time (h)", y="Plasma concentration (mg/L)") +
  th
gp

#############################################################################################
#############################################################################################


#############################################################################################
##########################################  Task 3  #########################################
#############################################################################################
# Run graphical sensitivity analysis for the blood:plasma concentration ratio (`BP`) and 
# lung:plasma partition coefficient (`Kplu`)

##' Define an intervention
e <- ev(cmt=cmt, amt=amt, rate=rate, ii= ii, addl=addl, ss=1)

## Sensitivity analysis on BP
idata <- tibble(BP = c(0.5, 1, 2)) %>% 
  mutate(ID = seq(n()))

modA %>%
  carry_out(BP) %>% 
  mrgsim_ei(e, idata, delta = 0.1, recsort=3, obsonly=TRUE, end = 12) %>% 
  as.data.frame() %>%
  mutate(BP = factor(BP)) %>%
  ggplot(aes(x=time, y=Cvenous, col=BP)) +
  geom_line() +
  labs(x="time (h)", y="Plasma concentration (mg/L)")

##' Sensitivity analysis on Kpki
idata <- tibble(Kplu=c(0.5, 1, 2)) %>% 
  mutate(ID = seq(n()))

modA %>%
  carry_out(Kplu) %>% 
  mrgsim_ei(e, idata, delta = 0.1, recsort=3, obsonly=TRUE, end = 12) %>% 
  as.data.frame() %>%
  mutate(Kplu = factor(Kplu)) %>%
  ggplot(aes(x=time, y=Cvenous, col=Kplu)) +
  geom_line() +
  labs(x="time (h)", y="Plasma concentration (mg/L)")

#############################################################################################
#############################################################################################


#############################################################################################
#########################################  Task 4  ##########################################
#############################################################################################
# Use package `FME` (https://cran.r-project.org/web/packages/FME/index.html) to run local 
# sensitivity analysis for the partition coefficient parameters using the FME package. What 
# is the most influential parameter?

### sensitivity analysis
#set a list of the candidate parameters
parms <- list(Kpad = 9.89, Kpbo = 7.91, Kpbr = 7.35, Kpgu = 5.82, Kphe = 1.95, Kpki = 2.9, 
              Kpli = 4.66, Kplu = 0.83, Kpmu = 2.94, Kpsp = 2.96, BP = 1) 

#set the output variable of interest
sensvar <- c("Cvenous")  

#set the output function
outFun <- function(pars){
  out <- as.data.frame(modA %>%
                         param(pars) %>%
                         ev(amt=amt, cmt=cmt, ii=ii, addl=addl, rate=rate, ss=ss) %>%
                         mrgsim(end=12, delta=0.1)) %>%
    dplyr::filter(row_number() != 1) 
  
  #get rid of ID because sensFun will take the first column as the time variable
  out <- out %>% dplyr::select(-ID)  
  return(out)
}

locSens <- sensFun(func=outFun, parms=parms, sensvar=sensvar)
summary(locSens)
plot(summary(locSens))

# nicer view
summ <- as_tibble(summary(locSens)) %>%
  mutate(parms = names(parms)) 

ggplot(data=summ, aes(x=reorder(parms, Mean), y=Mean)) + 
  geom_col() + 
  labs(x="Parameter", y="Coefficient") +
  coord_flip() +
  geom_hline(yintercept = 0, lty=2) 

#############################################################################################
#############################################################################################

#############################################################################################
#########################################  Task 5  ##########################################
#############################################################################################
# Use package `nloptr` (https://cran.r-project.org/web/packages/nloptr/index.html) to optimize 
# for most influential partition coefficient parameter and compare prediction before and after 
# optimization to observed data. 

### optimization with maximum likelihood method
theta <- log(c(BP=1, sigma2=1))  #initial parameter for MLE; mean and variance
sampl <- obs$time  #sampling times from observed data

bw <- 73
amt = 4*bw
rate = 4*bw
cmt = "VEN"
ii = 12
addl = 13
ss = 1

##set up objective function
OF <- function(pars, pred=F){
  pars %<>% lapply(exp)  #Get out of log domain for MLE
  pars <- as.list(pars)
  names(pars) <- names(theta)
  
  ## Get a prediction
  out <- as.data.frame(modA %>% 
                         param(pars) %>%
                         ev(cmt=cmt, amt=amt, rate=rate, ii=ii, addl=addl, ss=ss) %>%
                         mrgsim(end=-1, add=sampl)
  )
  
  out <- out[-1,] 
  
  if(pred) return(out)
  
  ##OLS
  #return(sum((out$Cvenous - obs$obs)^2))
  
  ##maximum likelihood
  return(-1*sum(dnorm(log(obs$obs),
                      mean=log(out$Cvenous),
                      sd=sqrt(pars$sigma2), log=TRUE)))
}

##Fit with nloptr package
##derivative-free optimizers
fit <- neldermead(theta, OF)  #Nelder-Mead simplex
#fit <- newuoa(theta, OF)  #New Unconstrained Optimization with quadratic Approximation

##gradient-basd optimizers
#fit <- tnewton(theta, OF)  #Local optimizer; Nelder-Mead simplex
#fit <- mlsl(theta, OF, lower=log(c(0.1)), upper=log(c(10)))  #global optimizer; multi-level single-linkage; takes very long ~ 10 min

##global optimizers
#fit <- direct(OF, lower=log(c(0.1, 0.1)), upper=log(c(10, 2)))  #DIviding RECTangles algorithm; takes ~ 3 min

fit

p <- as.list(exp(fit$par))  #get the parameters on the linear scale
names(p) <- names(theta)
p

predB4 <- OF(theta, pred=T)
predAfter <- OF(fit$par, pred=T)

gp <- ggplot() +
  geom_point(data=obs, aes(x=time, y=obs)) + 
  geom_errorbar(data=obs, aes(x=time, y=obs, ymin=obs-sd, ymax=obs+sd), width=0) +
  geom_line(data=predB4, aes(x=time, y=Cvenous), lty=2) +
  geom_line(data=predAfter, aes(x=time, y=Cvenous)) +
  labs(x="time (h)", y="Plasma concentration (mg/L)")
gp

#############################################################################################
#############################################################################################

#############################################################################################
#########################################  Task 6  ##########################################
#############################################################################################
# Generate pediatric model

# pediatric (5 yo) male physiology; https://www.ncbi.nlm.nih.gov/pubmed/14506981
pedPhys <- list(WEIGHT = 19,
                Vad = 5.5,
                Vbo = 2.43,
                Vbr = 1.31,
                VguWall = 0.22,
                VguLumen = 0.117,
                Vhe = 0.085,
                Vki = 0.11,
                Vli = 0.467,
                Vlu = 0.125,
                Vmu = 5.6,
                Vsp = 0.05,
                Vbl = 1.5,
                Qad = 0.05*3.4*60,
                Qbo = 0.05*3.4*60,
                Qbr = 0.12*3.4*60,
                Qgu = 0.15*3.4*60, 
                Qhe = 0.04*3.4*60,
                Qki = 0.19*3.4*60,
                Qmu = 0.17*3.4*60,
                Qsp = 0.03*3.4*60,
                Qha = 0.065*3.4*60, 
                Qlu = 3.4*60,
                MPPGL = 26,
                VmaxH = 120.5,
                KmH = 11)

modP <- param(modA, pedPhys)

#############################################################################################
#############################################################################################

#############################################################################################
##########################################  Task 7  #########################################
#############################################################################################
# Simulate a 4 mg/kg voriconazole IV infusion dosing in a male child subject infused at a rate 
# of 3 mg/kg/h twice a day for seven days. Compare the steady state prediction before and after 
# optimization to the observed data in `Pediatric_IV.csv`

obs <- read.csv("Pediatric_IV.csv")  #load observed data

wt <- 19  #adult body weight
amt <- 4*wt  
rate <- 3*wt
cmt <- "VEN"  #intravenous infusion
ii = 12
addl = 13
ss = 1

# simulate
simB4 <- as.data.frame(modP %>%
                         ev(amt=amt, cmt=cmt, ii=ii, addl=addl, rate=rate, ss=1) %>% 
                         mrgsim(delta = 0.1, end = 12)) %>% 
  dplyr::filter(row_number() != 1)  

simAfter <- as.data.frame(modP %>%
                            param(BP=p$BP) %>%
                            ev(amt=amt, cmt=cmt, ii=ii, addl=addl, rate=rate, ss=1) %>% 
                            mrgsim(delta = 0.1, end = 12)) %>% 
  dplyr::filter(row_number() != 1)

# plot
gp <- ggplot() + 
  geom_point(data = obs, aes(x=time, y=obs), size=2.5) + 
  geom_errorbar(data = obs, aes(x = time, y = obs, ymin=obs-sd, ymax=obs+sd), width=0) +
  geom_line(data = simB4, aes(x=time, y=Cvenous), lty=2) + 
  geom_line(data = simAfter, aes(x=time, y=Cvenous)) + 
  labs(title="Pediatric 4 mg/kg IV", x="time (h)", y="Plasma concentration (mg/L)") +
  th
gp
